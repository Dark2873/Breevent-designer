document.addEventListener('DOMContentLoaded', () => {
  const loginContainer = document.getElementById('login-container');
  const registerContainer = document.getElementById('register-container');
  const forgotPasswordContainer = document.getElementById('forgot-password-container');
  const resendCodeButton = document.getElementById('resend-code');
  const resendTimer = document.getElementById('resend-timer');

  let resendTimeout;

  function startResendTimer() {
    let timeLeft = 60;
    resendCodeButton.disabled = true;
    resendTimer.textContent = `Reenviar em ${timeLeft}s`;

    resendTimeout = setInterval(() => {
      timeLeft--;
      resendTimer.textContent = `Reenviar em ${timeLeft}s`;
      if (timeLeft <= 0) {
        clearInterval(resendTimeout);
        resendCodeButton.disabled = false;
        resendTimer.textContent = '';
      }
    }, 1000);
  }

  resendCodeButton.addEventListener('click', () => {
    console.log('Código de verificação reenviado.');
    startResendTimer();
  });

  document.getElementById('forgot-password-link').addEventListener('click', (e) => {
    e.preventDefault();
    loginContainer.style.display = 'none';
    forgotPasswordContainer.style.display = 'block';
  });

  document.getElementById('register-link').addEventListener('click', (e) => {
    e.preventDefault();
    loginContainer.style.display = 'none';
    registerContainer.style.display = 'block';
  });

  document.getElementById('back-to-login').addEventListener('click', (e) => {
    e.preventDefault();
    registerContainer.style.display = 'none';
    loginContainer.style.display = 'block';
  });

  document.getElementById('back-to-login-from-forgot').addEventListener('click', (e) => {
    e.preventDefault();
    forgotPasswordContainer.style.display = 'none';
    loginContainer.style.display = 'block';
  });

  document.getElementById('togglePassword').addEventListener('click', (e) => {
    const passwordField = document.getElementById('password');
    const type = passwordField.type === 'password' ? 'text' : 'password';
    passwordField.type = type;
    e.target.textContent = type === 'password' ? '👁' : '👁️';
  });

  document.getElementById('register-toggle-password').addEventListener('click', (e) => {
    const passwordField = document.getElementById('register-password');
    const type = passwordField.type === 'password' ? 'text' : 'password';
    passwordField.type = type;
    e.target.textContent = type === 'password' ? '👁' : '👁️';
  });

  document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
  });

  document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();
  });

  document.getElementById('forgot-password-form').addEventListener('submit', (e) => {
    e.preventDefault();
  });
});
